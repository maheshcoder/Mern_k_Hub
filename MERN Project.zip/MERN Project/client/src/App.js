// App.js
import React from 'react';
import './styles.css';
import Navbar from './components/Navbar';
import Header from './components/Header';
import DataInput from './components/DataInput';
import DataVisualization from './components/DataVisualization';

const App = () => {
  return (
    <div>
      <Navbar />
      <main>
        <Header />
        <div className="center">
          <DataInput />
        </div>
        <div className="chart-container">
          <DataVisualization />
        </div>
      </main>
      {/* Add a footer component or any additional content as needed */}
    </div>
  );
};

export default App;
