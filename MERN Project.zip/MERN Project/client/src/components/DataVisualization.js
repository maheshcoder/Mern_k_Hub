// DataVisualization.js
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Line } from 'react-chartjs-2';

const DataVisualization = () => {
  const [data, setData] = useState([]);

  useEffect(() => {
    // Fetch data from the server
    fetchData();
  }, []);

  const fetchData = () => {
    // Fetch data from both manual input and uploaded data endpoints
    axios.all([axios.get('/api/data'), axios.get('/api/uploaded-data')])
      .then(axios.spread((manualDataRes, uploadedDataRes) => {
        const mergedData = [...manualDataRes.data, ...uploadedDataRes.data];
        setData(mergedData);
      }))
      .catch((err) => console.error(err));
  };

  // Prepare the chart data and options
  const chartData = {
    labels: data.map(item => item.field1),
    datasets: [
      {
        label: 'Field 2',
        data: data.map(item => item.field2),
        fill: false,
        borderColor: 'rgba(75, 192, 192, 1)',
        tension: 0.1,
      },
    ],
  };

  const chartOptions = {
    scales: {
      y: {
        beginAtZero: true,
      },
    },
  };

  return (
    <div>
      <h2>Data Visualization</h2>
      {data.length > 0 ? (
        <div className="chart-container">
          <Line data={chartData} options={chartOptions} />
        </div>
      ) : (
        <p>No data available. Please input data or upload a data file to see visualizations.</p>
      )}
    </div>
  );
};

export default DataVisualization;
