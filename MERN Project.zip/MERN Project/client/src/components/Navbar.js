// Navbar.js
import React from 'react';

const Navbar = () => {
  return (
    <nav>
      <h1>My Data Visualization App</h1>
      {/* Add any navigation links or buttons as needed */}
    </nav>
  );
};

export default Navbar;
