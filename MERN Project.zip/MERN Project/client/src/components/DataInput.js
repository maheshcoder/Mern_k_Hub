import React, { useState } from 'react';
import axios from 'axios';

const DataInput = () => {
  const [field1, setField1] = useState('');
  const [field2, setField2] = useState('');
  const [selectedFile, setSelectedFile] = useState(null);

  const handleFileChange = (event) => {
    const file = event.target.files[0];
    setSelectedFile(file);
  };

  const handleSubmit = (event) => {
    event.preventDefault();

    if (selectedFile) {
      const formData = new FormData();
      formData.append('file', selectedFile);

      axios.post('/api/upload', formData)
        .then((res) => {
          console.log(res.data);
        })
        .catch((err) => {
          console.error(err);
        });
    } else {
      const data = {
        field1,
        field2,
      };

      axios.post('/api/data', data)
        .then((res) => {
          console.log(res.data);
        })
        .catch((err) => {
          console.error(err);
        });
    }

    setField1('');
    setField2('');
    setSelectedFile(null);
  };

  return (
    <div>
      <h2>Data Input Form</h2>
      <form onSubmit={handleSubmit}>
        <label>
          Field 1:
          <input type="text" value={field1} onChange={(e) => setField1(e.target.value)} />
        </label>
        <br />
        <label>
          Field 2:
          <input type="number" value={field2} onChange={(e) => setField2(e.target.value)} />
        </label>
        <br />
        <button type="submit">Submit</button>
      </form>
      <div>
        <label htmlFor="file">Upload Data File:</label>
        <input
          type="file"
          id="file"
          accept=".csv,.txt,.json"
          onChange={handleFileChange}
        />
      </div>
    </div>
  );
};

export default DataInput;
