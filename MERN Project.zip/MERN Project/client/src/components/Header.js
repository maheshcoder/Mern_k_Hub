// Header.js
import React from 'react';

const Header = () => {
  return (
    <header>
      <h2>Welcome to My Data Visualization App</h2>
      {/* You can add a brief description or call-to-action here */}
    </header>
  );
};

export default Header;
